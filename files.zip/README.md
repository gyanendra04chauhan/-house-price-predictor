# 🏠 House Price Predictor

A machine learning web application that predicts house sale prices using **Linear Regression**, built with Python, Scikit-learn, and Streamlit.

![Python](https://img.shields.io/badge/Python-3.9+-blue?logo=python)
![Streamlit](https://img.shields.io/badge/Streamlit-1.32+-red?logo=streamlit)
![Scikit-learn](https://img.shields.io/badge/Scikit--learn-1.3+-orange?logo=scikit-learn)
![License](https://img.shields.io/badge/License-MIT-green)

---

## 🔗 Live Demo

👉 **[Try it live on Streamlit Cloud](YOUR_APP_URL_HERE)**

---

## 📊 Model Performance

| Metric | Score |
|--------|-------|
| R² Score | 0.37 |
| MAE | $30,829 |
| RMSE | $41,138 |

---

## 🚀 Features

- 🔮 Instant house price prediction based on 11 property features
- 📊 Dataset explorer to browse raw data
- 📈 Price distribution visualization
- 🎯 Price range estimate (prediction ± MAE)
- 📱 Responsive, clean UI

---

## 🧠 ML Pipeline

```
CSV Data → Preprocessing → Feature Encoding (get_dummies) → 
Train/Test Split (80/20) → StandardScaler → Linear Regression → Prediction
```

**Features used:**
- MSSubClass, MSZoning, LotArea, LotConfig
- BldgType, OverallCond, YearBuilt, YearRemodAdd
- Exterior1st, BsmtFinSF2, TotalBsmtSF

---

## 🖥️ Run Locally

```bash
# 1. Clone the repo
git clone https://github.com/YOUR_USERNAME/house-price-predictor.git
cd house-price-predictor

# 2. Install dependencies
pip install -r requirements.txt

# 3. Run the app
streamlit run app.py
```

Open `http://localhost:8501` in your browser.

---

## 📁 Project Structure

```
house-price-predictor/
├── app.py                    # Main Streamlit application
├── HousePricePrediction.csv  # Dataset (Ames Housing)
├── requirements.txt          # Python dependencies
└── README.md
```

---

## ☁️ Deploy to Streamlit Cloud

1. Push this repo to GitHub
2. Go to [share.streamlit.io](https://share.streamlit.io)
3. Click **New app** → select this repo → `app.py` → Deploy

---

## 👨‍💻 Author

**Gyanendra Chauhan**  
B.Tech CSE (AI & ML) — Axis Institute of Technology & Management, Kanpur  
[GitHub](https://github.com/YOUR_USERNAME) · [LinkedIn](https://linkedin.com/in/YOUR_PROFILE)
